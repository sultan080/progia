import { X, QrCode } from 'lucide-react';
import { motion } from 'motion/react';

interface PaymentModalProps {
  onClose: () => void;
}

export default function PaymentModal({ onClose }: PaymentModalProps) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col p-8 space-y-6"
      >
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">Оплата Премиум</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400">
            <X size={24} />
          </button>
        </div>

        <div className="space-y-4 text-center">
          <p className="text-gray-600">
            Для активации Премиум тарифа (490 ₽/мес) отсканируйте QR-код ниже и совершите перевод через приложение СберБанк.
          </p>
          
          <div className="bg-gray-50 p-6 rounded-[2rem] border-2 border-dashed border-gray-200 flex flex-col items-center justify-center space-y-4">
            {/* Placeholder for QR Code */}
            <div className="w-48 h-48 bg-white rounded-2xl shadow-sm flex items-center justify-center border border-gray-100 relative">
              <QrCode size={120} className="text-gray-200" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest text-center px-4">
                  Ваш QR-код из Сбербанка
                </div>
              </div>
            </div>
            <div className="text-sm font-medium text-gray-500">
              Получатель: Султанмурад А.
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-2xl text-left space-y-2">
            <h4 className="text-sm font-bold text-blue-800 uppercase tracking-wider">Инструкция:</h4>
            <ol className="text-xs text-blue-700 space-y-1 list-decimal list-inside">
              <li>Откройте приложение СберБанк</li>
              <li>Выберите "Оплата по QR или штрихкоду"</li>
              <li>Отсканируйте код выше</li>
              <li>Введите сумму 490 ₽ и подтвердите перевод</li>
              <li>После оплаты доступ активируется в течение 15 минут</li>
            </ol>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-4 bg-[#4F46E5] text-white rounded-2xl font-bold hover:bg-[#4338CA] transition-all shadow-lg shadow-indigo-100 active:scale-95"
        >
          Я оплатил
        </button>
      </motion.div>
    </div>
  );
}
