import { useEffect, useState } from 'react';
import { db } from '../firebase';
import { collection, query, where, onSnapshot, orderBy, doc, deleteDoc, addDoc, serverTimestamp, increment, updateDoc } from 'firebase/firestore';
import { Tutor, Student, Lesson } from '../types';
import { Plus, Search, User, GraduationCap, ChevronRight, Trash2, LayoutDashboard, BookOpen, Users, FileDown, CheckCircle2, AlertCircle, Clock, Settings, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';
import StudentForm from './StudentForm';
import PaymentModal from './PaymentModal';
import WeeklySchedule from './WeeklySchedule';
import { motion, AnimatePresence } from 'motion/react';
import React from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

interface DashboardProps {
  tutor: Tutor | null;
}

export default function Dashboard({ tutor }: DashboardProps) {
  const [students, setStudents] = useState<Student[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddingStudent, setIsAddingStudent] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!tutor) return;

    const studentsQuery = query(
      collection(db, 'students'),
      where('tutorId', '==', tutor.uid),
      orderBy('createdAt', 'desc')
    );

    const lessonsQuery = query(
      collection(db, 'lessons'),
      where('tutorId', '==', tutor.uid)
    );

    const unsubscribeStudents = onSnapshot(studentsQuery, (snapshot) => {
      const studentData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Student[];
      
      // Ensure new students appear at the top even if createdAt is still pending from server
      const sortedData = [...studentData].sort((a, b) => {
        const timeA = a.createdAt ? (typeof a.createdAt === 'object' && 'seconds' in a.createdAt ? (a.createdAt as any).seconds * 1000 : new Date(a.createdAt).getTime()) : Date.now() + 1000;
        const timeB = b.createdAt ? (typeof b.createdAt === 'object' && 'seconds' in b.createdAt ? (b.createdAt as any).seconds * 1000 : new Date(b.createdAt).getTime()) : Date.now() + 1000;
        return timeB - timeA;
      });

      setStudents(sortedData);
      setLoading(false);
    }, (error) => {
      console.error('Error in students snapshot listener:', error);
      setLoading(false);
    });

    const unsubscribeLessons = onSnapshot(lessonsQuery, (snapshot) => {
      const lessonData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Lesson[];
      setLessons(lessonData);
    }, (error) => {
      console.error('Error in lessons snapshot listener:', error);
    });

    return () => {
      unsubscribeStudents();
      unsubscribeLessons();
    };
  }, [tutor]);

  // Auto-add lessons logic
  useEffect(() => {
    if (!tutor || students.length === 0 || loading) return;

    const checkAndAddLessons = async () => {
      const now = new Date();
      const daysRu = ['Воскресенье', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'];
      const currentDayRu = daysRu[now.getDay()];
      const currentTime = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');

      for (const student of students) {
        const todaySchedule = student.schedule?.filter(item => item.day === currentDayRu) || [];
        
        for (const item of todaySchedule) {
          // If scheduled time has passed
          if (item.time <= currentTime) {
            // Check if lesson already exists for this student today
            const todayStart = new Date();
            todayStart.setHours(0, 0, 0, 0);
            const todayEnd = new Date();
            todayEnd.setHours(23, 59, 59, 999);

            const hasLessonToday = lessons.some(l => 
              l.studentId === student.id && 
              new Date(l.date) >= todayStart && 
              new Date(l.date) <= todayEnd
            );

            if (!hasLessonToday) {
              // Auto-add lesson
              try {
                await addDoc(collection(db, 'lessons'), {
                  studentId: student.id,
                  tutorId: tutor.uid,
                  topic: 'Запланированный урок',
                  date: new Date().toISOString(),
                  grade: 5,
                  homework: '',
                  isPaid: false,
                  attended: true,
                  files: [],
                  createdAt: serverTimestamp(),
                });
                
                await updateDoc(doc(db, 'stats', 'global'), {
                  lessonsCount: increment(1)
                });
              } catch (error) {
                console.error('Error auto-adding lesson:', error);
              }
            }
          }
        }
      }
    };

    checkAndAddLessons();
  }, [students, lessons, tutor, loading]);

  const filteredStudents = students.filter(s =>
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDeleteStudent = async (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (window.confirm('Вы уверены, что хотите удалить этого ученика? Все записи уроков будут потеряны.')) {
      await deleteDoc(doc(db, 'students', id));
    }
  };

  const exportToPDF = async () => {
    const element = document.getElementById('dashboard-report-container');
    if (!element) return;

    // Show the report container temporarily but keep it off-screen
    element.style.display = 'block';
    element.style.position = 'fixed';
    element.style.left = '0';
    element.style.top = '0';
    element.style.zIndex = '-1';
    
    try {
      const canvas = await html2canvas(element, { 
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#F9FAFB',
        windowWidth: 1200,
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save('dashboard_report.pdf');
    } catch (error) {
      console.error('PDF Export failed:', error);
    } finally {
      // Hide the report container again
      element.style.display = 'none';
      element.style.position = 'absolute';
      element.style.left = '-9999px';
    }
  };

  if (loading && students.length === 0) {
    return <div className="animate-pulse text-center py-12 text-gray-400">Загрузка учеников...</div>;
  }

  return (
    <div className="space-y-8" id="dashboard-main-content">
      {/* Header & Stats */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">С возвращением, {tutor?.displayName}</h1>
          <p className="text-gray-500">У вас {students.length} активных учеников.</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={exportToPDF}
            className="flex items-center gap-2 bg-white text-gray-700 border border-gray-200 px-6 py-3 rounded-2xl font-bold hover:bg-gray-50 transition-all shadow-sm active:scale-95"
          >
            <FileDown size={20} />
            Экспорт PDF
          </button>
          <button
            onClick={() => setIsAddingStudent(true)}
            className="flex items-center gap-2 bg-[#4F46E5] text-white px-6 py-3 rounded-2xl font-bold hover:bg-[#4338CA] transition-all shadow-lg shadow-indigo-100 active:scale-95"
          >
            <Plus size={20} />
            Добавить ученика
          </button>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-gray-400 uppercase tracking-widest">Всего учеников</span>
            <Users size={20} className="text-blue-500" />
          </div>
          <div className="text-3xl font-black text-gray-900">{students.length}</div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-gray-400 uppercase tracking-widest">Проведено уроков</span>
            <BookOpen size={20} className="text-indigo-500" />
          </div>
          <div className="text-3xl font-black text-gray-900">
            {lessons.length}
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-gray-400 uppercase tracking-widest">Неоплачено</span>
            <AlertCircle size={20} className="text-red-500" />
          </div>
          <div className="text-3xl font-black text-red-500">
            {lessons.filter(l => !l.isPaid).length}
          </div>
        </div>
      </div>

      {/* PRO Banner */}
      {tutor?.plan === 'free' && (
        <div className="bg-[#FFF7ED] border border-[#FFEDD5] rounded-[2rem] p-6 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
          <div className="flex items-center gap-6">
            <div className="w-14 h-14 bg-[#FFEDD5] rounded-2xl flex items-center justify-center shrink-0">
              <Lock className="text-[#EA580C]" size={24} />
            </div>
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-[#7C2D12]">Разблокируйте дашборды прогресса</h3>
              <p className="text-sm text-[#9A3412] leading-relaxed">
                Перейдите на PRO тариф за 490 ₽/мес, чтобы получить доступ к визуальной аналитике по каждому ученику для отправки родителям.
              </p>
            </div>
          </div>
          <button 
            onClick={() => setShowPayment(true)}
            className="bg-[#FF5C00] text-white px-8 py-3 rounded-2xl font-bold hover:bg-[#E65300] transition-all shadow-lg shadow-orange-100 active:scale-95 whitespace-nowrap"
          >
            Улучшить тариф
          </button>
        </div>
      )}

      {/* Weekly Schedule */}
      <WeeklySchedule students={students} />

      {/* Student List Section */}
      <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden" id="students-list-container">
        <div className="p-6 border-b border-gray-50 flex flex-col sm:flex-row justify-between gap-4">
          <h2 className="text-xl font-bold text-gray-900">Ученики</h2>
          <div className="relative no-print">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Поиск учеников..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 w-full sm:w-64 transition-all"
            />
          </div>
        </div>

        <div className="divide-y divide-gray-50">
          {filteredStudents.length > 0 ? (
            filteredStudents.map((student) => {
              const studentLessons = lessons.filter(l => l.studentId === student.id);
              const unpaidLessons = studentLessons.filter(l => !l.isPaid);
              const lastLesson = studentLessons.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
              const progress = Math.round(((student.completedTasks?.length || 0) / student.taskCount) * 100);

              return (
                <Link
                  key={student.id}
                  to={`/student/${student.id}`}
                  className="group block p-6 hover:bg-gray-50 transition-all"
                >
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 font-bold text-lg group-hover:bg-indigo-600 group-hover:text-white transition-all">
                        {student.name.charAt(0)}
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">{student.name}</h3>
                        <div className="flex items-center gap-3 text-sm text-gray-400">
                          <span className="flex items-center gap-1"><BookOpen size={14} /> {student.subject}</span>
                          <span className="w-1 h-1 bg-gray-300 rounded-full" />
                          <span className="flex items-center gap-1"><GraduationCap size={14} /> {student.examType}</span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 flex-1 lg:max-w-2xl">
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Уроков</span>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-gray-700">{studentLessons.length}</span>
                          {unpaidLessons.length > 0 && (
                            <span className="text-xs font-bold text-red-500 flex items-center gap-0.5">
                              <AlertCircle size={12} /> {unpaidLessons.length}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="space-y-1 col-span-2">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Последний урок</span>
                        {lastLesson ? (
                          <div className="text-xs space-y-0.5">
                            <div className="flex items-center gap-1 text-gray-600 font-bold">
                              <Clock size={12} /> {new Date(lastLesson.date).toLocaleDateString('ru-RU')}
                            </div>
                            <div className="text-gray-500 truncate max-w-[150px]">{lastLesson.topic}</div>
                          </div>
                        ) : (
                          <span className="text-xs text-gray-300 italic">Нет уроков</span>
                        )}
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-end">
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Прогресс</span>
                          <span className="text-xs font-bold text-indigo-600">
                            {student.completedTasks?.length || 0} / {student.taskCount}
                          </span>
                        </div>
                        <div className="h-2.5 w-full bg-gray-100 rounded-full overflow-hidden shadow-inner">
                          <div 
                            className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-1000"
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 no-print">
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setEditingStudent(student);
                          setIsAddingStudent(true);
                        }}
                        className="p-2 text-gray-300 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                      >
                        <Settings size={18} />
                      </button>
                      <button
                        onClick={(e) => handleDeleteStudent(student.id, e)}
                        className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                      >
                        <Trash2 size={18} />
                      </button>
                      <ChevronRight className="text-gray-300 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" size={20} />
                    </div>
                  </div>
                </Link>
              );
            })
          ) : (
            <div className="p-12 text-center text-gray-400">
              <Users size={48} className="mx-auto mb-4 opacity-20" />
              <p>Ученики не найдены. Добавьте своего первого ученика!</p>
            </div>
          )}
        </div>
      </div>

      {/* Add/Edit Student Modal */}
      <AnimatePresence>
        {isAddingStudent && (
          <StudentForm
            tutorId={tutor?.uid || ''}
            student={editingStudent || undefined}
            onClose={() => {
              setIsAddingStudent(false);
              setEditingStudent(null);
            }}
          />
        )}
      </AnimatePresence>

      {/* Payment Modal */}
      <AnimatePresence>
        {showPayment && (
          <PaymentModal onClose={() => setShowPayment(false)} />
        )}
      </AnimatePresence>

      {/* Hidden Report Container for PDF Export */}
      <div 
        id="dashboard-report-container" 
        style={{ 
          display: 'none', 
          position: 'absolute', 
          left: '-9999px', 
          top: 0, 
          width: '1200px', 
          padding: '40px', 
          background: '#F9FAFB',
          color: '#111827',
          fontFamily: 'Inter, sans-serif'
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h1 style={{ fontSize: '36px', fontWeight: 900, color: '#111827', margin: 0 }}>Сводный отчет: {tutor?.displayName}</h1>
            <div style={{ textAlign: 'right' }}>
              <p style={{ fontSize: '14px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em', margin: 0 }}>Дата отчета</p>
              <p style={{ fontSize: '18px', fontWeight: 700, color: '#111827', margin: 0 }}>{new Date().toLocaleDateString('ru-RU')}</p>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '24px' }}>
            <div style={{ background: '#FFFFFF', padding: '24px', borderRadius: '24px', border: '1px solid #F3F4F6', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)' }}>
              <span style={{ fontSize: '14px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Всего учеников</span>
              <div style={{ fontSize: '30px', fontWeight: 900, color: '#111827' }}>{students.length}</div>
            </div>
            <div style={{ background: '#FFFFFF', padding: '24px', borderRadius: '24px', border: '1px solid #F3F4F6', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)' }}>
              <span style={{ fontSize: '14px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Проведено уроков</span>
              <div style={{ fontSize: '30px', fontWeight: 900, color: '#111827' }}>{lessons.length}</div>
            </div>
            <div style={{ background: '#FFFFFF', padding: '24px', borderRadius: '24px', border: '1px solid #F3F4F6', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)' }}>
              <span style={{ fontSize: '14px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Неоплачено</span>
              <div style={{ fontSize: '30px', fontWeight: 900, color: '#EF4444' }}>{lessons.filter(l => !l.isPaid).length}</div>
            </div>
          </div>

          <div style={{ background: '#FFFFFF', borderRadius: '32px', border: '1px solid #F3F4F6', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)', overflow: 'hidden' }}>
            <div style={{ padding: '24px', borderBottom: '1px solid #F9FAFB' }}>
              <h2 style={{ fontSize: '20px', fontWeight: 700, color: '#111827', margin: 0 }}>Статистика по ученикам</h2>
            </div>
            <table style={{ width: '100%', textAlign: 'left', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: '#F9FAFB' }}>
                  <th style={{ padding: '16px', fontSize: '12px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Ученик</th>
                  <th style={{ padding: '16px', fontSize: '12px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Предмет</th>
                  <th style={{ padding: '16px', fontSize: '12px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Уроков</th>
                  <th style={{ padding: '16px', fontSize: '12px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Прогресс</th>
                  <th style={{ padding: '16px', fontSize: '12px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Статус оплаты</th>
                </tr>
              </thead>
              <tbody>
                {students.map(student => {
                  const studentLessons = lessons.filter(l => l.studentId === student.id);
                  const unpaid = studentLessons.filter(l => !l.isPaid).length;
                  const progress = Math.round(((student.completedTasks?.length || 0) / student.taskCount) * 100);
                  return (
                    <tr key={student.id} style={{ borderBottom: '1px solid #F9FAFB' }}>
                      <td style={{ padding: '16px', fontWeight: 700, color: '#111827' }}>{student.name}</td>
                      <td style={{ padding: '16px', color: '#6B7280' }}>{student.subject} ({student.examType})</td>
                      <td style={{ padding: '16px', color: '#111827', fontWeight: 700 }}>{studentLessons.length}</td>
                      <td style={{ padding: '16px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <div style={{ height: '8px', width: '96px', background: '#F3F4F6', borderRadius: '9999px', overflow: 'hidden' }}>
                            <div style={{ height: '100%', background: '#6366F1', width: `${progress}%` }} />
                          </div>
                          <span style={{ fontSize: '12px', fontWeight: 700, color: '#4F46E5' }}>{progress}%</span>
                        </div>
                      </td>
                      <td style={{ padding: '16px' }}>
                        {unpaid > 0 ? (
                          <span style={{ fontSize: '12px', fontWeight: 700, color: '#EF4444' }}>Неоплачено: {unpaid}</span>
                        ) : (
                          <span style={{ fontSize: '12px', fontWeight: 700, color: '#10B981' }}>Оплачено</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
