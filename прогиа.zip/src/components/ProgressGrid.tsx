import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface ProgressGridProps {
  total: number;
  completed: number[];
  onToggle?: (index: number) => void;
}

export default function ProgressGrid({ total, completed, onToggle }: ProgressGridProps) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {Array.from({ length: total }).map((_, i) => {
        const isCompleted = completed.includes(i + 1);
        return (
          <motion.button
            key={i}
            whileHover={onToggle ? { scale: 1.2, zIndex: 10 } : {}}
            whileTap={onToggle ? { scale: 0.9 } : {}}
            onClick={() => onToggle?.(i + 1)}
            disabled={!onToggle}
            className={cn(
              "w-6 h-6 rounded-md border transition-all duration-300 flex items-center justify-center text-[8px] font-black shrink-0",
              isCompleted
                ? "bg-[#4F46E5] border-[#4F46E5] text-[#FFFFFF]"
                : "bg-[#FFFFFF] border-[#F3F4F6] text-[#D1D5DB] hover:border-indigo-200 hover:text-indigo-300",
              !onToggle && "cursor-default shadow-none"
            )}
            title={`Задание ${i + 1}: ${isCompleted ? 'Выполнено' : 'Не выполнено'}`}
          >
            {i + 1}
          </motion.button>
        );
      })}
    </div>
  );
}
