import { User } from 'firebase/auth';
import { logOut, signInWithGoogle } from '../firebase';
import { Tutor } from '../types';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, User as UserIcon, GraduationCap, ChevronDown } from 'lucide-react';
import { cn } from '../lib/utils';
import { useState } from 'react';
import ProfileModal from './ProfileModal';
import { AnimatePresence } from 'motion/react';

interface NavbarProps {
  user: User | null;
  tutor: Tutor | null;
}

export default function Navbar({ user, tutor }: NavbarProps) {
  const navigate = useNavigate();
  const [showProfile, setShowProfile] = useState(false);

  const handleLogout = async () => {
    await logOut();
    navigate('/');
  };

  return (
    <nav className="bg-white border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-[#4F46E5] rounded-xl flex items-center justify-center text-white shadow-sm group-hover:bg-[#4338CA] transition-colors">
              <GraduationCap size={24} />
            </div>
            <span className="text-xl font-bold tracking-tight text-gray-900">ПРОГИА</span>
          </Link>

          <div className="flex items-center gap-4">
            {user ? (
              <>
                <button 
                  onClick={() => setShowProfile(true)}
                  className="flex items-center gap-3 group px-3 py-1.5 rounded-2xl hover:bg-gray-50 transition-all"
                >
                  <div className="hidden sm:flex flex-col items-end">
                    <span className="text-sm font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">{tutor?.displayName}</span>
                    <span className={cn(
                      "text-[10px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded-full",
                      tutor?.plan === 'paid' ? "bg-amber-100 text-amber-700" : "bg-gray-100 text-gray-500"
                    )}>
                      {tutor?.plan === 'paid' ? 'Премиум' : 'Бесплатно'}
                    </span>
                  </div>
                  <ChevronDown size={14} className="text-gray-400 group-hover:text-indigo-600 transition-colors" />
                </button>
                <button
                  onClick={handleLogout}
                  className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                  title="Выйти"
                >
                  <LogOut size={20} />
                </button>
              </>
            ) : (
              <button
                onClick={signInWithGoogle}
                className="bg-[#4F46E5] text-white px-5 py-2 rounded-xl font-medium hover:bg-[#4338CA] transition-all shadow-sm active:scale-95"
              >
                Войти
              </button>
            )}
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showProfile && tutor && (
          <ProfileModal tutor={tutor} onClose={() => setShowProfile(false)} />
        )}
      </AnimatePresence>
    </nav>
  );
}
