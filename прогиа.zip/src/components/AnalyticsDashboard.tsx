import { Lesson, Student } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, Legend } from 'recharts';
import { motion } from 'motion/react';

interface AnalyticsDashboardProps {
  lessons: Lesson[];
  student: Student;
}

export default function AnalyticsDashboard({ lessons, student }: AnalyticsDashboardProps) {
  // 1. Grade Dynamics (Line Chart)
  const lineData = [...lessons]
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .map(l => ({
      date: new Date(l.date).toLocaleDateString('ru-RU', { month: 'short', day: 'numeric' }),
      grade: l.grade,
    }));

  // 2. Grade Distribution (Bar Chart)
  const distributionData = [1, 2, 3, 4, 5].map(g => ({
    grade: g,
    count: lessons.filter(l => l.grade === g).length,
  }));

  // 3. Payment Status (Pie Chart)
  const paymentData = [
    { name: 'Оплачено', value: lessons.filter(l => l.isPaid).length, color: '#10B981' },
    { name: 'Не оплачено', value: lessons.filter(l => !l.isPaid).length, color: '#EF4444' },
  ];

  // 4. Attendance (Pie Chart)
  const attendanceData = [
    { name: 'Присутствовал', value: lessons.filter(l => l.attended !== false).length, color: '#4F46E5' },
    { name: 'Пропущено', value: lessons.filter(l => l.attended === false).length, color: '#F59E0B' },
  ];

  const missedLessonsCount = lessons.filter(l => l.attended === false).length;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Grade Dynamics */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-[#FFFFFF] p-8 rounded-[2.5rem] border border-[#F3F4F6] space-y-6"
      >
        <h3 className="text-lg font-bold text-[#111827]">Динамика оценок</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={lineData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F3F4F6" />
              <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#9CA3AF' }} />
              <YAxis domain={[1, 5]} axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#9CA3AF' }} />
              <Tooltip
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
                itemStyle={{ fontWeight: 'bold', color: '#4F46E5' }}
              />
              <Line
                type="monotone"
                dataKey="grade"
                stroke="#4F46E5"
                strokeWidth={4}
                dot={{ r: 6, fill: '#4F46E5', strokeWidth: 2, stroke: '#fff' }}
                activeDot={{ r: 8, strokeWidth: 0 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Grade Distribution */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-[#FFFFFF] p-8 rounded-[2.5rem] border border-[#F3F4F6] space-y-6"
      >
        <h3 className="text-lg font-bold text-[#111827]">Распределение оценок</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={distributionData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F3F4F6" />
              <XAxis dataKey="grade" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#9CA3AF' }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#9CA3AF' }} />
              <Tooltip
                cursor={{ fill: '#F9FAFB' }}
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
              />
              <Bar dataKey="count" fill="#818CF8" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Attendance (Pie) */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-[#FFFFFF] p-8 rounded-[2.5rem] border border-[#F3F4F6] space-y-6"
      >
        <h3 className="text-lg font-bold text-[#111827]">Посещаемость</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={attendanceData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {attendanceData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
              />
              <Legend verticalAlign="bottom" height={36} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Payment Status (Pie) */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-[#FFFFFF] p-8 rounded-[2.5rem] border border-[#F3F4F6] space-y-6"
      >
        <h3 className="text-lg font-bold text-[#111827]">Статус оплаты</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={paymentData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {paymentData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
              />
              <Legend verticalAlign="bottom" height={36} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Summary Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-[#4F46E5] p-8 rounded-[2.5rem] flex flex-col justify-center text-[#FFFFFF] space-y-4 lg:col-span-2"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-1">
            <span className="text-xs font-bold text-[#C7D2FE] uppercase tracking-widest">Средняя оценка</span>
            <div className="text-5xl font-black">
              {lessons.length > 0
                ? (lessons.reduce((acc, l) => acc + l.grade, 0) / lessons.length).toFixed(1)
                : '0.0'}
            </div>
          </div>
          <div className="space-y-1">
            <span className="text-xs font-bold text-[#C7D2FE] uppercase tracking-widest">Всего уроков</span>
            <div className="text-3xl font-black">{lessons.length}</div>
          </div>
          <div className="space-y-1">
            <span className="text-xs font-bold text-[#C7D2FE] uppercase tracking-widest">Пропущено уроков</span>
            <div className="text-3xl font-black text-[#FCD34D]">{missedLessonsCount}</div>
          </div>
        </div>
        <div className="pt-4 border-t border-indigo-400/30">
          <p className="text-sm text-[#E0E7FF]">
            Отличная работа! Регулярная обратная связь помогает ученикам достигать целей быстрее.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
