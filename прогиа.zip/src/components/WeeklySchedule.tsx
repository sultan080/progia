import { Student } from '../types';
import { Clock, Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { useState } from 'react';
import React from 'react';

interface WeeklyScheduleProps {
  students: Student[];
}

const DAYS = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
const DAYS_EN = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function WeeklySchedule({ students }: WeeklyScheduleProps) {
  const [currentWeekOffset, setCurrentWeekOffset] = useState(0);

  const scheduleByDay = DAYS.map((dayName, index) => {
    const dayLessons = students.flatMap(student => 
      (student.schedule || [])
        .filter(item => item.day === dayName)
        .map(item => ({
          ...item,
          studentName: student.name,
          studentId: student.id,
          subject: student.subject
        }))
    ).sort((a, b) => a.time.localeCompare(b.time));

    return {
      name: dayName,
      lessons: dayLessons
    };
  });

  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
            <CalendarIcon size={20} />
          </div>
          <h2 className="text-xl font-bold text-gray-900">Расписание на неделю</h2>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
        {scheduleByDay.map((day, idx) => (
          <div key={idx} className="space-y-4">
            <div className="text-center pb-2 border-b border-gray-50">
              <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">{day.name}</span>
            </div>
            <div className="space-y-2">
              {day.lessons.length > 0 ? (
                day.lessons.map((lesson, lIdx) => (
                  <motion.div
                    key={lIdx}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-3 bg-gray-50 rounded-xl border border-transparent hover:border-indigo-100 hover:bg-white transition-all group cursor-pointer"
                  >
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-indigo-600 mb-1">
                      <Clock size={10} />
                      {lesson.time}
                    </div>
                    <p className="text-xs font-bold text-gray-900 truncate group-hover:text-indigo-600 transition-colors">
                      {lesson.studentName}
                    </p>
                    <p className="text-[9px] text-gray-400 font-medium truncate">
                      {lesson.subject}
                    </p>
                  </motion.div>
                ))
              ) : (
                <div className="py-8 text-center">
                  <span className="text-[10px] text-gray-300 italic">Нет занятий</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
