import { useState } from 'react';
import { db } from '../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { X, User, Mail, BookOpen, Save } from 'lucide-react';
import { motion } from 'motion/react';
import { Tutor } from '../types';
import React from 'react';

interface ProfileModalProps {
  tutor: Tutor;
  onClose: () => void;
}

export default function ProfileModal({ tutor, onClose }: ProfileModalProps) {
  const [displayName, setDisplayName] = useState(tutor.displayName);
  const [subject, setSubject] = useState(tutor.subject || '');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await updateDoc(doc(db, 'tutors', tutor.uid), {
        displayName,
        subject,
      });
      onClose();
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/20 backdrop-blur-sm"
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl overflow-hidden"
      >
        <div className="p-8 border-b border-gray-50 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">Профиль</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="flex justify-center mb-8">
            <div className="relative">
              <img 
                src={tutor.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(tutor.displayName)}&background=4F46E5&color=fff`} 
                alt={tutor.displayName}
                className="w-24 h-24 rounded-[2rem] object-cover shadow-lg border-4 border-white"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-2 -right-2 bg-white p-2 rounded-xl shadow-md border border-gray-100">
                <User size={16} className="text-indigo-600" />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Имя</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                required
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Предмет</label>
            <div className="relative">
              <BookOpen className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Математика, Физика..."
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Email</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                disabled
                type="email"
                value={tutor.email}
                className="w-full pl-12 pr-4 py-4 bg-gray-100 border-none rounded-2xl font-medium text-gray-500 cursor-not-allowed"
              />
            </div>
          </div>

          <button
            disabled={isSubmitting}
            type="submit"
            className="w-full py-4 bg-[#4F46E5] text-white rounded-2xl font-bold text-lg hover:bg-[#4338CA] transition-all shadow-xl shadow-indigo-100 disabled:opacity-50 active:scale-95 flex items-center justify-center gap-2"
          >
            <Save size={20} />
            {isSubmitting ? 'Сохранение...' : 'Сохранить изменения'}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
