import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { db, auth } from '../firebase';
import { doc, onSnapshot, collection, query, where, orderBy, updateDoc, arrayUnion, arrayRemove } from 'firebase/firestore';
import { Student, Lesson, Tutor } from '../types';
import { ChevronLeft, Plus, Calendar, BookOpen, GraduationCap, LayoutDashboard, TrendingUp, History, User, Settings, Share2, FileDown, Phone, Info, CheckCircle2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ProgressGrid from './ProgressGrid';
import LessonForm from './LessonForm';
import StudentForm from './StudentForm';
import AnalyticsDashboard from './AnalyticsDashboard';
import { cn } from '../lib/utils';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

interface StudentDetailProps {
  tutor: Tutor | null;
}

export default function StudentDetail({ tutor }: StudentDetailProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [student, setStudent] = useState<Student | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [activeTab, setActiveTab] = useState<'history' | 'analytics'>('history');
  const [isAddingLesson, setIsAddingLesson] = useState(false);
  const [isEditingStudent, setIsEditingStudent] = useState(false);
  const [editingLesson, setEditingLesson] = useState<Lesson | null>(null);
  const [loading, setLoading] = useState(true);
  const [isCopying, setIsCopying] = useState(false);

  const isTutor = auth.currentUser?.uid === student?.tutorId;

  useEffect(() => {
    if (!id) return;

    const studentUnsubscribe = onSnapshot(doc(db, 'students', id), (doc) => {
      if (doc.exists()) {
        setStudent({ id: doc.id, ...doc.data() } as Student);
      } else {
        navigate('/dashboard');
      }
      setLoading(false);
    }, (error) => {
      console.error('Error in student snapshot listener:', error);
      setLoading(false);
    });

    const lessonsQuery = query(
      collection(db, 'lessons'),
      where('studentId', '==', id),
      orderBy('date', 'desc')
    );

    const lessonsUnsubscribe = onSnapshot(lessonsQuery, (snapshot) => {
      const lessonData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Lesson[];
      setLessons(lessonData);
    }, (error) => {
      console.error('Error in lessons snapshot listener:', error);
    });

    return () => {
      studentUnsubscribe();
      lessonsUnsubscribe();
    };
  }, [id, navigate]);

  const toggleTask = async (taskIndex: number) => {
    if (!student || !id || !isTutor) return;
    const isCompleted = student.completedTasks?.includes(taskIndex);
    await updateDoc(doc(db, 'students', id), {
      completedTasks: isCompleted ? arrayRemove(taskIndex) : arrayUnion(taskIndex)
    });
  };

  const handleShare = async () => {
    const shareUrl = window.location.href;
    try {
      await navigator.clipboard.writeText(shareUrl);
      setIsCopying(true);
      setTimeout(() => setIsCopying(false), 2000);
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const exportToPDF = async () => {
    const element = document.getElementById('student-report-container');
    if (!element) return;

    // Show the report container temporarily but keep it off-screen
    element.style.display = 'block';
    element.style.position = 'fixed';
    element.style.left = '0';
    element.style.top = '0';
    element.style.zIndex = '-1';

    try {
      const canvas = await html2canvas(element, { 
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#F9FAFB',
        windowWidth: 1200,
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`${student?.name}_report.pdf`);
    } catch (error) {
      console.error('PDF Export failed:', error);
    } finally {
      // Hide the report container again
      element.style.display = 'none';
      element.style.position = 'absolute';
      element.style.left = '-9999px';
    }
  };

  if (loading) return <div className="animate-pulse text-center py-12 text-gray-400">Загрузка данных ученика...</div>;
  if (!student) return null;

  const progress = Math.round(((student.completedTasks?.length || 0) / student.taskCount) * 100);

  return (
    <div className="space-y-8 pb-24" id="student-dashboard-content">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 no-print">
        <button
          onClick={() => navigate('/dashboard')}
          className="flex items-center gap-2 text-gray-400 hover:text-gray-600 transition-colors font-medium"
        >
          <ChevronLeft size={20} />
          Назад в панель
        </button>
        <div className="flex items-center gap-2">
          <button 
            onClick={exportToPDF}
            className="flex items-center gap-2 px-4 py-2 bg-white text-gray-700 border border-gray-200 rounded-xl font-bold hover:bg-gray-50 transition-all shadow-sm active:scale-95"
          >
            <FileDown size={18} />
            Экспорт PDF
          </button>
          <button 
            onClick={handleShare}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-xl font-bold transition-all shadow-sm active:scale-95",
              isCopying ? "bg-green-500 text-white" : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
            )}
          >
            <Share2 size={18} />
            {isCopying ? 'Ссылка скопирована!' : 'Поделиться'}
          </button>
          {isTutor && (
            <button 
              onClick={() => setIsEditingStudent(true)}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-all"
            >
              <Settings size={20} />
            </button>
          )}
        </div>
      </div>

      {/* Student Profile Card */}
      <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm flex flex-col md:flex-row gap-8 items-start">
        <div className="w-24 h-24 bg-indigo-50 rounded-[2rem] flex items-center justify-center text-indigo-600 font-black text-3xl shadow-inner">
          {student.name.charAt(0)}
        </div>
        <div className="flex-1 space-y-4">
          <div className="space-y-1">
            <h1 className="text-3xl font-black text-gray-900">{student.name}</h1>
            <p className="text-gray-500 font-medium">{student.goal}</p>
          </div>
          <div className="flex flex-wrap gap-4 no-print">
            <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-xl text-sm font-bold text-gray-600">
              <BookOpen size={16} className="text-indigo-500" />
              {student.subject}
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-xl text-sm font-bold text-gray-600">
              <GraduationCap size={16} className="text-purple-500" />
              {student.examType}
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-xl text-sm font-bold text-gray-600">
              <Calendar size={16} className="text-blue-500" />
              {student.schedule.length} занятий/нед
            </div>
          </div>
          
          {(student.parentName || student.parentPhone || student.description) && (
            <div className="pt-4 border-t border-gray-50 space-y-3">
              <div className="flex flex-wrap gap-6">
                {student.parentName && (
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <User size={16} className="text-gray-400" />
                    <span className="font-bold text-gray-700">Родитель:</span> {student.parentName}
                  </div>
                )}
                {student.parentPhone && (
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Phone size={16} className="text-gray-400" />
                    <span className="font-bold text-gray-700">Тел:</span> {student.parentPhone}
                  </div>
                )}
              </div>
              {student.description && (
                <div className="flex items-start gap-2 text-sm text-gray-500">
                  <Info size={16} className="text-gray-400 mt-0.5 shrink-0" />
                  <p><span className="font-bold text-gray-700">Заметки:</span> {student.description}</p>
                </div>
              )}
            </div>
          )}
        </div>
        <div className="w-full md:w-64 space-y-4">
          <div className="flex justify-between items-end">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Общий прогресс</span>
            <span className="text-2xl font-black text-indigo-600">{progress}%</span>
          </div>
          <div className="h-3 w-full bg-gray-100 rounded-full overflow-hidden shadow-inner">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full"
            />
          </div>
        </div>
      </div>

      {/* Progress Grid */}
      <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <LayoutDashboard size={20} />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Прогресс обучения</h2>
          </div>
          <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">
            Выполнено {student.completedTasks?.length || 0} / {student.taskCount} заданий
          </span>
        </div>
        <ProgressGrid
          total={student.taskCount}
          completed={student.completedTasks || []}
          onToggle={isTutor ? toggleTask : undefined}
        />
        {!isTutor && (
          <p className="text-xs text-center text-gray-400 italic">Редактирование доступно только репетитору.</p>
        )}
      </div>

      {/* Tabs & Content */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex p-1 bg-gray-100 rounded-2xl w-fit">
            <button
              onClick={() => setActiveTab('history')}
              className={cn(
                "flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-sm transition-all",
                activeTab === 'history' ? "bg-white text-gray-900 shadow-sm" : "text-gray-400 hover:text-gray-600"
              )}
            >
              <History size={18} />
              История уроков
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={cn(
                "flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-sm transition-all",
                activeTab === 'analytics' ? "bg-white text-gray-900 shadow-sm" : "text-gray-400 hover:text-gray-600"
              )}
            >
              <TrendingUp size={18} />
              Аналитика
            </button>
          </div>
          {activeTab === 'history' && isTutor && (
            <button
              onClick={() => setIsAddingLesson(true)}
              className="flex items-center gap-2 bg-[#4F46E5] text-white px-5 py-2.5 rounded-xl font-bold hover:bg-[#4338CA] transition-all shadow-lg shadow-indigo-100 active:scale-95"
            >
              <Plus size={18} />
              Добавить урок
            </button>
          )}
        </div>

        <AnimatePresence mode="wait">
          {activeTab === 'history' ? (
            <motion.div
              key="history"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              {lessons.length > 0 ? (
                lessons.map((lesson) => (
                  <div 
                    key={lesson.id} 
                    onClick={() => {
                      if (isTutor) {
                        setEditingLesson(lesson);
                        setIsAddingLesson(true);
                      }
                    }}
                    className={cn(
                      "bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-all group",
                      isTutor && "cursor-pointer"
                    )}
                  >
                    <div className="flex flex-col md:flex-row justify-between gap-6">
                      <div className="space-y-4 flex-1">
                        <div className="flex items-center gap-3">
                          <div className="px-3 py-1 bg-gray-50 text-gray-500 text-xs font-bold rounded-lg">
                            {new Date(lesson.date).toLocaleDateString('ru-RU', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </div>
                          <h3 className="text-lg font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">{lesson.topic}</h3>
                          {lesson.attended === false && (
                            <span className="px-2 py-0.5 bg-red-50 text-red-600 text-[10px] font-black uppercase tracking-widest rounded-md">
                              Пропущено
                            </span>
                          )}
                        </div>
                        <div className="space-y-2">
                          <p className="text-sm text-gray-500 leading-relaxed">
                            <span className="font-bold text-gray-400 uppercase text-[10px] tracking-widest block mb-1">Домашнее задание</span>
                            {lesson.homework || 'Задание не назначено.'}
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-row md:flex-col items-center md:items-end justify-between md:justify-center gap-4">
                        <div className="flex flex-col items-center md:items-end">
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Оценка</span>
                          <div className={cn(
                            "text-3xl font-black",
                            lesson.grade >= 4 ? "text-green-500" : lesson.grade >= 3 ? "text-amber-500" : "text-red-500"
                          )}>
                            {lesson.grade}
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          {lesson.isPaid ? (
                            <div className="flex items-center gap-1 text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded-lg">
                              <CheckCircle2 size={14} /> Оплачено
                            </div>
                          ) : (
                            <div className="flex items-center gap-1 text-xs font-bold text-red-600 bg-red-50 px-2 py-1 rounded-lg">
                              <AlertCircle size={14} /> Не оплачено
                            </div>
                          )}
                          {lesson.files?.length > 0 && (
                            <div className="flex gap-1">
                              {lesson.files.map((file, i) => (
                                <div key={i} className="w-8 h-8 bg-gray-50 rounded-lg flex items-center justify-center text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 cursor-pointer transition-all">
                                  <Share2 size={14} />
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="bg-white p-12 rounded-3xl border border-dashed border-gray-200 text-center text-gray-400">
                  <History size={48} className="mx-auto mb-4 opacity-10" />
                  <p>Уроки пока не записаны. Начните с добавления первого занятия!</p>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="analytics"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <AnalyticsDashboard lessons={lessons} student={student} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Add/Edit Lesson Modal */}
      <AnimatePresence>
        {isAddingLesson && (
          <LessonForm
            studentId={student.id}
            tutorId={tutor?.uid || ''}
            lesson={editingLesson || undefined}
            onClose={() => {
              setIsAddingLesson(false);
              setEditingLesson(null);
            }}
          />
        )}
      </AnimatePresence>

      {/* Edit Student Modal */}
      <AnimatePresence>
        {isEditingStudent && (
          <StudentForm
            tutorId={tutor?.uid || ''}
            student={student}
            onClose={() => setIsEditingStudent(false)}
          />
        )}
      </AnimatePresence>

      {/* Hidden Report Container for PDF Export */}
      <div 
        id="student-report-container" 
        style={{ 
          display: 'none', 
          position: 'absolute', 
          left: '-9999px', 
          top: 0, 
          width: '1200px', 
          padding: '40px', 
          background: '#F9FAFB',
          color: '#111827',
          fontFamily: 'Inter, sans-serif'
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h1 style={{ fontSize: '36px', fontWeight: 900, color: '#111827', margin: 0 }}>Отчет по ученику: {student.name}</h1>
            <div style={{ textAlign: 'right' }}>
              <p style={{ fontSize: '14px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em', margin: 0 }}>Дата отчета</p>
              <p style={{ fontSize: '18px', fontWeight: 700, color: '#111827', margin: 0 }}>{new Date().toLocaleDateString('ru-RU')}</p>
            </div>
          </div>

          <div style={{ background: '#FFFFFF', padding: '32px', borderRadius: '40px', border: '1px solid #F3F4F6', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)', display: 'flex', gap: '32px', alignItems: 'flex-start' }}>
            <div style={{ width: '96px', height: '96px', background: '#EEF2FF', borderRadius: '32px', display: 'flex', alignItems: 'center', justifyItems: 'center', color: '#4F46E5', fontWeight: 900, fontSize: '30px', justifyContent: 'center' }}>
              {student.name.charAt(0)}
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                <h2 style={{ fontSize: '30px', fontWeight: 900, color: '#111827', margin: 0 }}>{student.name}</h2>
                <p style={{ color: '#6B7280', fontWeight: 500, margin: 0 }}>{student.goal}</p>
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px', background: '#F9FAFB', borderRadius: '12px', fontSize: '14px', fontWeight: 700, color: '#4B5563' }}>
                  <BookOpen size={16} style={{ color: '#6366F1' }} />
                  {student.subject}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px', background: '#F9FAFB', borderRadius: '12px', fontSize: '14px', fontWeight: 700, color: '#4B5563' }}>
                  <GraduationCap size={16} style={{ color: '#A855F7' }} />
                  {student.examType}
                </div>
              </div>
            </div>
            <div style={{ width: '256px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
                <span style={{ fontSize: '12px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Общий прогресс</span>
                <span style={{ fontSize: '24px', fontWeight: 900, color: '#4F46E5' }}>{progress}%</span>
              </div>
              <div style={{ height: '12px', width: '100%', background: '#F3F4F6', borderRadius: '9999px', overflow: 'hidden' }}>
                <div
                  style={{ height: '100%', background: 'linear-gradient(to right, #6366F1, #A855F7)', width: `${progress}%`, borderRadius: '9999px' }}
                />
              </div>
            </div>
          </div>

          <div style={{ background: '#FFFFFF', padding: '32px', borderRadius: '40px', border: '1px solid #F3F4F6', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)', display: 'flex', flexDirection: 'column', gap: '24px' }}>
            <h2 style={{ fontSize: '20px', fontWeight: 700, color: '#111827', margin: 0 }}>Прогресс обучения</h2>
            <ProgressGrid
              total={student.taskCount}
              completed={student.completedTasks || []}
            />
          </div>

          <div style={{ background: '#FFFFFF', padding: '32px', borderRadius: '40px', border: '1px solid #F3F4F6', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)', display: 'flex', flexDirection: 'column', gap: '32px' }}>
            <h2 style={{ fontSize: '20px', fontWeight: 700, color: '#111827', margin: 0 }}>Аналитика и статистика</h2>
            <AnalyticsDashboard lessons={lessons} student={student} />
          </div>

          <div style={{ background: '#FFFFFF', padding: '32px', borderRadius: '40px', border: '1px solid #F3F4F6', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)', display: 'flex', flexDirection: 'column', gap: '24px' }}>
            <h2 style={{ fontSize: '20px', fontWeight: 700, color: '#111827', margin: 0 }}>История уроков</h2>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
              <thead>
                <tr style={{ borderBottom: '2px solid #F3F4F6' }}>
                  <th style={{ padding: '12px', fontSize: '12px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase' }}>Дата</th>
                  <th style={{ padding: '12px', fontSize: '12px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase' }}>Тема</th>
                  <th style={{ padding: '12px', fontSize: '12px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase' }}>Оценка</th>
                  <th style={{ padding: '12px', fontSize: '12px', fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase' }}>Статус</th>
                </tr>
              </thead>
              <tbody>
                {lessons.map((lesson) => (
                  <tr key={lesson.id} style={{ borderBottom: '1px solid #F9FAFB' }}>
                    <td style={{ padding: '12px', fontSize: '14px', color: '#4B5563' }}>
                      {new Date(lesson.date).toLocaleDateString('ru-RU')}
                    </td>
                    <td style={{ padding: '12px', fontSize: '14px', fontWeight: 700, color: '#111827' }}>
                      {lesson.topic}
                    </td>
                    <td style={{ padding: '12px' }}>
                      <span style={{ 
                        padding: '4px 12px', 
                        borderRadius: '8px', 
                        fontSize: '14px', 
                        fontWeight: 900,
                        background: lesson.grade >= 4 ? '#ECFDF5' : lesson.grade === 3 ? '#FFFBEB' : '#FEF2F2',
                        color: lesson.grade >= 4 ? '#059669' : lesson.grade === 3 ? '#D97706' : '#DC2626'
                      }}>
                        {lesson.grade}
                      </span>
                    </td>
                    <td style={{ padding: '12px', fontSize: '14px', color: lesson.isPaid ? '#059669' : '#DC2626', fontWeight: 700 }}>
                      {lesson.isPaid ? 'Оплачено' : 'Не оплачено'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
