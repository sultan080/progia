import { useState } from 'react';
import { db } from '../firebase';
import { collection, addDoc, serverTimestamp, doc, updateDoc, increment } from 'firebase/firestore';
import { X, Plus, Trash2, Calendar, Clock, BookOpen, Star } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import React from 'react';

import { Lesson } from '../types';

interface LessonFormProps {
  studentId: string;
  tutorId: string;
  onClose: () => void;
  lesson?: Lesson;
}

export default function LessonForm({ studentId, tutorId, onClose, lesson }: LessonFormProps) {
  const [topic, setTopic] = useState(lesson?.topic || '');
  const [date, setDate] = useState(lesson?.date ? new Date(lesson.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
  const [grade, setGrade] = useState(lesson?.grade || 5);
  const [homework, setHomework] = useState(lesson?.homework || '');
  const [isPaid, setIsPaid] = useState(lesson ? lesson.isPaid : true);
  const [attended, setAttended] = useState(lesson ? lesson.attended : true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic || !date) return;

    setIsSubmitting(true);
    
    const lessonData = {
      topic,
      date: new Date(date).toISOString(),
      grade,
      homework,
      isPaid,
      attended,
    };

    try {
      if (lesson) {
        // Update existing lesson
        await updateDoc(doc(db, 'lessons', lesson.id), lessonData);
      } else {
        // Create new lesson
        await addDoc(collection(db, 'lessons'), {
          ...lessonData,
          studentId,
          tutorId,
          files: [],
          createdAt: serverTimestamp(),
        });
        
        // Update global stats
        await updateDoc(doc(db, 'stats', 'global'), {
          lessonsCount: increment(1)
        });
      }
      onClose();
    } catch (error) {
      console.error('Error saving lesson:', error);
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/20 backdrop-blur-sm"
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-8 border-b border-gray-50 flex justify-between items-center bg-white sticky top-0 z-10">
          <h2 className="text-2xl font-bold text-gray-900">
            {lesson ? 'Редактировать урок' : 'Записать новый урок'}
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8 overflow-y-auto">
          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Тема урока</label>
            <div className="relative">
              <BookOpen className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                required
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="Введение в производные"
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Дата</label>
              <div className="relative">
                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <input
                  required
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Оценка (1-5)</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => setGrade(g)}
                    className={cn(
                      "flex-1 py-4 rounded-2xl font-black transition-all",
                      grade === g
                        ? "bg-[#4F46E5] text-white shadow-lg shadow-indigo-100"
                        : "bg-gray-50 text-gray-400 hover:bg-gray-100"
                    )}
                  >
                    {g}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Домашнее задание</label>
            <textarea
              value={homework}
              onChange={(e) => setHomework(e.target.value)}
              placeholder="Решить задачи 1-10 на странице 42..."
              rows={4}
              className="w-full px-4 py-4 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium resize-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-2xl">
              <input
                type="checkbox"
                id="isPaid"
                checked={isPaid}
                onChange={(e) => setIsPaid(e.target.checked)}
                className="w-6 h-6 rounded-lg border-gray-200 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
              />
              <label htmlFor="isPaid" className="text-sm font-bold text-gray-700 cursor-pointer select-none">
                Урок оплачен
              </label>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-2xl">
              <input
                type="checkbox"
                id="attended"
                checked={attended}
                onChange={(e) => setAttended(e.target.checked)}
                className="w-6 h-6 rounded-lg border-gray-200 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
              />
              <label htmlFor="attended" className="text-sm font-bold text-gray-700 cursor-pointer select-none">
                Присутствовал
              </label>
            </div>
          </div>
        </form>

        <div className="p-8 border-t border-gray-50 bg-white sticky bottom-0 z-10">
          <button
            disabled={isSubmitting}
            onClick={handleSubmit}
            className="w-full py-4 bg-[#4F46E5] text-white rounded-2xl font-bold text-lg hover:bg-[#4338CA] transition-all shadow-xl shadow-indigo-100 disabled:opacity-50 active:scale-95"
          >
            {isSubmitting ? 'Запись...' : 'Сохранить урок'}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
