import { useEffect, useState } from 'react';
import { db, signInWithGoogle } from '../firebase';
import { doc, getDoc, setDoc, updateDoc, increment } from 'firebase/firestore';
import { motion } from 'motion/react';
import { Users, BookOpen, GraduationCap, CheckCircle2, TrendingUp, LayoutDashboard, QrCode } from 'lucide-react';
import PaymentModal from './PaymentModal';
import { AnimatePresence } from 'motion/react';

interface Stats {
  tutorsCount: number;
  studentsCount: number;
  lessonsCount: number;
}

export default function LandingPage() {
  const [stats, setStats] = useState<Stats>({
    tutorsCount: 124,
    studentsCount: 842,
    lessonsCount: 5431,
  });

  const [showPayment, setShowPayment] = useState(false);

  useEffect(() => {
    const fetchStats = async () => {
      const statsDoc = await getDoc(doc(db, 'stats', 'global'));
      if (statsDoc.exists()) {
        setStats(statsDoc.data() as Stats);
      } else {
        // Initialize stats if not present
        await setDoc(doc(db, 'stats', 'global'), {
          tutorsCount: 124,
          studentsCount: 842,
          lessonsCount: 5431,
        });
      }
    };
    fetchStats();
  }, []);

  return (
    <div className="space-y-24 py-12">
      {/* Hero Section */}
      <section className="text-center space-y-8 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-4"
        >
          <h1 className="text-6xl font-extrabold tracking-tight text-gray-900 leading-tight">
            Ваш идеальный <span className="text-[#4F46E5]">инструмент</span> для репетиторства
          </h1>
          <p className="text-xl text-gray-500 max-w-2xl mx-auto leading-relaxed">
            Управляйте учениками, отслеживайте прогресс с аналитикой и визуализируйте результаты обучения в одном минималистичном дашборде.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <button
            onClick={signInWithGoogle}
            className="w-full sm:w-auto px-8 py-4 bg-[#4F46E5] text-white rounded-2xl font-bold text-lg hover:bg-[#4338CA] transition-all shadow-xl shadow-indigo-200 active:scale-95"
          >
            Начать бесплатно
          </button>
        </motion.div>
      </section>

      {/* Metrics Section */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { label: 'Активных репетиторов', value: stats.tutorsCount, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Учеников обучается', value: stats.studentsCount, icon: GraduationCap, color: 'text-indigo-600', bg: 'bg-indigo-50' },
          { label: 'Уроков проведено', value: stats.lessonsCount, icon: BookOpen, color: 'text-purple-600', bg: 'bg-purple-50' },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + i * 0.1 }}
            className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow text-center space-y-4"
          >
            <div className={`w-14 h-14 ${stat.bg} ${stat.color} rounded-2xl flex items-center justify-center mx-auto`}>
              <stat.icon size={28} />
            </div>
            <div className="space-y-1">
              <div className="text-4xl font-black text-gray-900">{stat.value.toLocaleString()}</div>
              <div className="text-sm font-semibold text-gray-400 uppercase tracking-wider">{stat.label}</div>
            </div>
          </motion.div>
        ))}
      </section>

      {/* Features Section */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div className="space-y-8">
          <h2 className="text-4xl font-bold text-gray-900 leading-tight">
            Визуальное отслеживание прогресса
          </h2>
          <div className="space-y-6">
            {[
              { title: 'Интерактивная сетка прогресса', desc: 'Визуализируйте выполнение задач с помощью чистой цветовой сетки.', icon: LayoutDashboard },
              { title: 'Аналитика успеваемости', desc: 'Отслеживайте динамику оценок и посещаемость с помощью красивых графиков.', icon: TrendingUp },
              { title: 'Управление учениками', desc: 'Держите всех своих учеников, расписание и материалы в одном месте.', icon: Users },
            ].map((feature) => (
              <div key={feature.title} className="flex gap-4">
                <div className="flex-shrink-0 w-12 h-12 bg-white border border-gray-100 rounded-xl flex items-center justify-center text-[#4F46E5] shadow-sm">
                  <feature.icon size={24} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900">{feature.title}</h3>
                  <p className="text-gray-500">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-full -mr-16 -mt-16 transition-transform group-hover:scale-150 duration-700" />
          <div className="relative space-y-6">
            <div className="flex items-center justify-between">
              <div className="h-4 w-32 bg-gray-100 rounded-full" />
              <div className="h-8 w-8 bg-indigo-100 rounded-lg" />
            </div>
            <div className="grid grid-cols-10 gap-2">
              {Array.from({ length: 30 }).map((_, i) => (
                <div
                  key={i}
                  className={`aspect-square rounded-md transition-all duration-500 ${
                    i < 12 ? 'bg-[#4F46E5] scale-100' : 'bg-gray-100 scale-95'
                  }`}
                />
              ))}
            </div>
            <div className="space-y-3">
              <div className="h-3 w-full bg-gray-50 rounded-full overflow-hidden">
                <div className="h-full w-[40%] bg-[#4F46E5]" />
              </div>
              <div className="flex justify-between text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                <span>Прогресс: 40%</span>
                <span>Цель: ЕГЭ 2026</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="text-center space-y-12">
        <div className="space-y-4">
          <h2 className="text-4xl font-bold text-gray-900">Простые и прозрачные цены</h2>
          <p className="text-gray-500">Выберите план, который подходит вашим потребностям.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <div className="bg-white p-10 rounded-3xl border border-gray-100 shadow-sm space-y-8 flex flex-col">
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-gray-900">Бесплатно</h3>
              <p className="text-gray-500">Для начинающих репетиторов</p>
            </div>
            <div className="text-5xl font-black text-gray-900">0₽<span className="text-lg text-gray-400 font-medium">/мес</span></div>
            <ul className="space-y-4 text-left flex-grow">
              {['До 5 учеников', 'Базовая история уроков', 'Управление расписанием'].map(item => (
                <li key={item} className="flex items-center gap-3 text-gray-600">
                  <CheckCircle2 size={18} className="text-green-500" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <button
              onClick={signInWithGoogle}
              className="w-full py-4 border-2 border-gray-100 rounded-2xl font-bold text-gray-900 hover:bg-gray-50 transition-all"
            >
              Начать бесплатно
            </button>
          </div>

          <div className="bg-white p-10 rounded-3xl border-2 border-[#4F46E5] shadow-xl shadow-indigo-100 space-y-8 flex flex-col relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-[#4F46E5] text-white px-4 py-1 text-xs font-bold uppercase tracking-widest rounded-bl-xl">Популярно</div>
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-gray-900">Премиум</h3>
              <p className="text-gray-500">Для профессионалов</p>
            </div>
            <div className="text-5xl font-black text-gray-900">490₽<span className="text-lg text-gray-400 font-medium">/мес</span></div>
            <ul className="space-y-4 text-left flex-grow">
              {['Безлимитное количество учеников', 'Продвинутая аналитика', 'Визуализация прогресса', 'Приоритетная поддержка'].map(item => (
                <li key={item} className="flex items-center gap-3 text-gray-600">
                  <CheckCircle2 size={18} className="text-indigo-500" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <button
              onClick={() => setShowPayment(true)}
              className="w-full py-4 bg-[#4F46E5] text-white rounded-2xl font-bold hover:bg-[#4338CA] transition-all shadow-lg shadow-indigo-200"
            >
              Купить Премиум
            </button>
          </div>
        </div>
      </section>

      <AnimatePresence>
        {showPayment && (
          <PaymentModal onClose={() => setShowPayment(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}
