import { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, addDoc, serverTimestamp, doc, updateDoc } from 'firebase/firestore';
import { ExamType, ScheduleItem, Student } from '../types';
import { X, Plus, Trash2, Calendar, Clock } from 'lucide-react';
import { motion } from 'motion/react';
import React from 'react';

interface StudentFormProps {
  tutorId: string;
  onClose: () => void;
  student?: Student;
}

export default function StudentForm({ tutorId, onClose, student }: StudentFormProps) {
  const [name, setName] = useState(student?.name || '');
  const [subject, setSubject] = useState(student?.subject || 'Математика');
  const [goal, setGoal] = useState(student?.goal || '');
  const [examType, setExamType] = useState<ExamType>(student?.examType || 'ЕГЭ');
  const [taskCount, setTaskCount] = useState(student?.taskCount || 27);
  const [schedule, setSchedule] = useState<ScheduleItem[]>(student?.schedule || []);
  const [parentName, setParentName] = useState(student?.parentName || '');
  const [parentPhone, setParentPhone] = useState(student?.parentPhone || '');
  const [description, setDescription] = useState(student?.description || '');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const subjects = ['Математика', 'Информатика', 'Физика', 'Русский язык', 'Обществознание', 'История', 'Биология', 'Химия', 'Английский язык'];
  const examDefaults = { 'ВПР': 15, 'ОГЭ': 25, 'ЕГЭ': 27 };

  const handleExamTypeChange = (type: ExamType) => {
    setExamType(type);
    if (!student) {
      setTaskCount(examDefaults[type]);
    }
  };

  const addScheduleItem = () => {
    setSchedule([...schedule, { day: 'Понедельник', time: '16:00' }]);
  };

  const removeScheduleItem = (index: number) => {
    setSchedule(schedule.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !goal) return;

    setIsSubmitting(true);
    
    const studentData = {
      name,
      subject,
      goal,
      examType,
      taskCount,
      schedule,
      parentName,
      parentPhone,
      description,
    };

    try {
      if (student) {
        // Update existing student
        await updateDoc(doc(db, 'students', student.id), studentData);
      } else {
        // Create new student
        await addDoc(collection(db, 'students'), {
          ...studentData,
          tutorId,
          completedTasks: [],
          createdAt: serverTimestamp(),
        });
      }
      onClose();
    } catch (error) {
      console.error('Error saving student:', error);
      setIsSubmitting(false);
      // We could add a toast here if we had one
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/20 backdrop-blur-sm"
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-2xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-8 border-b border-gray-50 flex justify-between items-center bg-white sticky top-0 z-10">
          <h2 className="text-2xl font-bold text-gray-900">
            {student ? 'Редактировать ученика' : 'Добавить ученика'}
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-400">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8 overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">ФИО Ученика</label>
              <input
                required
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Иван Иванов"
                className="w-full px-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Предмет</label>
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
              >
                {subjects.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Цель подготовки</label>
            <input
              required
              type="text"
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              placeholder="90+ баллов на ЕГЭ 2026"
              className="w-full px-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Имя родителя</label>
              <input
                type="text"
                value={parentName}
                onChange={(e) => setParentName(e.target.value)}
                placeholder="Мария Иванова"
                className="w-full px-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Телефон родителя</label>
              <input
                type="tel"
                value={parentPhone}
                onChange={(e) => setParentPhone(e.target.value)}
                placeholder="+7 (999) 000-00-00"
                className="w-full px-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Описание / Заметки</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Особенности ученика, уровень знаний..."
              rows={3}
              className="w-full px-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium resize-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Тип экзамена</label>
              <div className="flex gap-2">
                {(['ВПР', 'ОГЭ', 'ЕГЭ'] as ExamType[]).map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => handleExamTypeChange(type)}
                    className={`flex-1 py-3 rounded-2xl font-bold transition-all ${
                      examType === type
                        ? 'bg-[#4F46E5] text-white shadow-lg shadow-indigo-100'
                        : 'bg-gray-50 text-gray-400 hover:bg-gray-100'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Количество заданий</label>
              <input
                type="number"
                value={taskCount}
                onChange={(e) => setTaskCount(parseInt(e.target.value))}
                className="w-full px-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-widest">Расписание</label>
              <button
                type="button"
                onClick={addScheduleItem}
                className="text-xs font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
              >
                <Plus size={14} /> Добавить день
              </button>
            </div>
            <div className="space-y-3">
              {schedule.map((item, index) => (
                <div key={index} className="flex items-center gap-3 bg-gray-50 p-3 rounded-2xl">
                  <div className="flex-1 flex items-center gap-2">
                    <Calendar size={16} className="text-gray-400" />
                    <select
                      value={item.day}
                      onChange={(e) => {
                        const newSchedule = [...schedule];
                        newSchedule[index].day = e.target.value;
                        setSchedule(newSchedule);
                      }}
                      className="bg-transparent border-none focus:ring-0 text-sm font-medium w-full"
                    >
                      {['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'].map(d => (
                        <option key={d} value={d}>{d}</option>
                      ))}
                    </select>
                  </div>
                  <div className="flex-1 flex items-center gap-2">
                    <Clock size={16} className="text-gray-400" />
                    <input
                      type="time"
                      value={item.time}
                      onChange={(e) => {
                        const newSchedule = [...schedule];
                        newSchedule[index].time = e.target.value;
                        setSchedule(newSchedule);
                      }}
                      className="bg-transparent border-none focus:ring-0 text-sm font-medium w-full"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => removeScheduleItem(index)}
                    className="p-2 text-gray-300 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
              {schedule.length === 0 && (
                <p className="text-xs text-gray-400 italic text-center py-2">Расписание не установлено.</p>
              )}
            </div>
          </div>
        </form>

        <div className="p-8 border-t border-gray-50 bg-white sticky bottom-0 z-10">
          <button
            disabled={isSubmitting}
            onClick={handleSubmit}
            className="w-full py-4 bg-[#4F46E5] text-white rounded-2xl font-bold text-lg hover:bg-[#4338CA] transition-all shadow-xl shadow-indigo-100 disabled:opacity-50 active:scale-95"
          >
            {isSubmitting ? (student ? 'Сохранение...' : 'Добавление...') : (student ? 'Сохранить изменения' : 'Создать ученика')}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
