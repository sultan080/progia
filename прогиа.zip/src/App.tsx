import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { onAuthStateChanged, User } from 'firebase/auth';
import { useEffect, useState } from 'react';
import { auth, db } from './firebase';
import { doc, getDoc, setDoc, serverTimestamp, onSnapshot } from 'firebase/firestore';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import StudentDetail from './components/StudentDetail';
import Navbar from './components/Navbar';
import { Tutor } from './types';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [tutor, setTutor] = useState<Tutor | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (authUser) => {
      if (authUser) {
        setUser(authUser);
        
        // Use onSnapshot for real-time tutor data updates
        const tutorRef = doc(db, 'tutors', authUser.uid);
        const unsubscribeTutor = onSnapshot(tutorRef, async (docSnap) => {
          if (docSnap.exists()) {
            setTutor({ ...docSnap.data() } as Tutor);
          } else {
            // New tutor registration
            const newTutor: Tutor = {
              uid: authUser.uid,
              email: authUser.email || '',
              displayName: authUser.displayName || 'Tutor',
              photoURL: authUser.photoURL || '',
              plan: 'free',
              createdAt: new Date().toISOString(),
            };
            await setDoc(tutorRef, {
              ...newTutor,
              createdAt: serverTimestamp(),
            });
            setTutor(newTutor);
          }
          setLoading(false);
        }, (error) => {
          console.error('Error in tutor snapshot listener:', error);
          setLoading(false);
        });

        return () => unsubscribeTutor();
      } else {
        setUser(null);
        setTutor(null);
        setLoading(false);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F9FAFB]">
        <div className="animate-pulse text-gray-400 font-medium">Загрузка...</div>
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-[#F9FAFB] text-[#111827] font-sans">
        <Navbar user={user} tutor={tutor} />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Routes>
            <Route path="/" element={!user ? <LandingPage /> : <Navigate to="/dashboard" />} />
            <Route path="/dashboard" element={user ? <Dashboard tutor={tutor} /> : <Navigate to="/" />} />
            <Route path="/student/:id" element={<StudentDetail tutor={tutor} />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}
