export type Plan = 'free' | 'paid';
export type ExamType = 'ВПР' | 'ОГЭ' | 'ЕГЭ';

export interface Tutor {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  subject?: string;
  plan: Plan;
  createdAt: any;
}

export interface ScheduleItem {
  day: string;
  time: string;
}

export interface Student {
  id: string;
  tutorId: string;
  name: string;
  subject: string;
  goal: string;
  examType: ExamType;
  taskCount: number;
  completedTasks: number[];
  schedule: ScheduleItem[];
  parentName?: string;
  parentPhone?: string;
  description?: string;
  createdAt: any;
}

export interface LessonFile {
  name: string;
  url: string;
}

export interface Lesson {
  id: string;
  studentId: string;
  tutorId: string;
  date: string;
  topic: string;
  grade: number;
  homework: string;
  files: LessonFile[];
  isPaid: boolean;
  attended: boolean;
}
